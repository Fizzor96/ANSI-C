#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

int main(int argc, char **argv)
{
    printf("\n");
    // Create def vars for storing data
    unsigned int charCountInFile = 1; // includes nullterm char, aka storage length
    char *storage;                    // char array to store our data

    // counting chars in file
    // hello.txt <- path placeholder
    FILE *fp = fopen("ex1.be", "r");
    for (char tempchar = getc(fp); tempchar != EOF; tempchar = getc(fp))
    {
        charCountInFile = charCountInFile + 1;
    }
    fclose(fp);

    // dyn alloc mem for our arr
    storage = malloc(sizeof(char) * charCountInFile);

    // load data into our arr
    // hello.txt <- path placeholder
    fp = fopen("ex1.be", "r");
    char c;
    for (unsigned int i = 0; i < charCountInFile; i++)
    {
        c = getc(fp);
        if (c == EOF)
        {
            storage[i] = 0x00;
            break;
        }
        // LOOK AT THIS MAN, this is how to use our char arr!
        storage[i] = c;
    }
    fclose(fp);

    printf("----------CHARCOUNT IN FILE------------\n");
    printf("charcount in file: %i\n", charCountInFile);
    printf("-----------ORIGINAL DATA---------------\n");
    printf("%s", storage);

    // char arr to int arr
    int storageAsIntArr[20][20];

    // init arr with def values
    for (size_t i = 0; i < 20; i++)
    {
        for (size_t j = 0; j < 20; j++)
        {
            storageAsIntArr[i][j] = 0;
        }
    }

    int rowindex = 0;
    int columnindex = 0;
    // fill int array with int values
    for (int i = 0; i < charCountInFile; i++)
    {
        if (storage[i] > ('0' - 1) && storage[i] < ('9' + 1))
        {
            storageAsIntArr[rowindex][columnindex] = storage[i] - '0';
            columnindex++;
        }
        if (storage[i] == '\n')
        {
            columnindex = 0;
            rowindex++;
        }
    }

    printf("--------------INTARRAY-----------------\n");
    // print int arr
    for (size_t i = 0; i < 5; i++)
    {
        for (size_t j = 0; j < 5; j++)
        {
            printf("%i ", storageAsIntArr[i][j]);
        }
        printf("\n");
    }
    printf("\t...\n");

    printf("--------------SNAILARR-----------------\n");
    int snailarr[20][20];
    // startpositions
    // fill snailarr
    for (size_t i = 0; i < 19; i++)
    {
        for (size_t j = 0; j < 20; j++)
        {
            snailarr[i][j] = storageAsIntArr[i + 1][j];
        }
    }
    // fill last line with 0s
    for (size_t i = 0; i < 20; i++)
    {
        snailarr[19][i] = 0;
    }

    for (size_t i = 0; i < 5; i++)
    {
        for (size_t j = 0; j < 5; j++)
        {
            printf("%i ", snailarr[i][j]);
        }
        printf("\n");
    }
    printf("\t...\n");

    printf("-----------SNAILPOSITIONS--------------\n");

    int snailpositions[2][50];
    //  snailpositions[i][j]
    //  i: rows -> i=0 == x position
    //  i: rows -> i=1 == y position
    //  eg. snailpositions[1][69] -> 69th y position
    snailpositions[0][0] = storageAsIntArr[0][0] - 1;
    snailpositions[1][0] = storageAsIntArr[0][1] - 1;

    int ispositive = 0;
    int counter = 1;
    for (size_t i = 1; i < 50; i++)
    {
        if (i % 2 != 0)
        {
            snailpositions[1][i] = snailpositions[1][i - 1];
            if (ispositive == 0)
            {
                snailpositions[0][i] = snailpositions[0][i - 1] - counter;
            }
            else
            {
                snailpositions[0][i] = snailpositions[0][i - 1] + counter;
            }
        }
        else
        {
            snailpositions[0][i] = snailpositions[0][i - 1];
            if (ispositive == 0)
            {
                snailpositions[1][i] = snailpositions[1][i - 1] - counter;
                ispositive = 1;
            }
            else
            {
                snailpositions[1][i] = snailpositions[1][i - 1] + counter;
                ispositive = 0;
            }
            counter++;
        }
    }

    for (size_t i = 0; i < 20; i++)
    {
        printf("%i: x=%i y=%i\n", i, snailpositions[0][i], snailpositions[1][i]);
    }
    printf("\t...\n");
    printf("-----------------OUTPUT----------------\n");

    int allpositions[2][1000];
    allpositions[0][0] = snailpositions[0][0];
    allpositions[1][0] = snailpositions[1][0];
    int atallposindex = 1;

    for (size_t i = 1; i < 4; i++)
    {
        int sxpos1 = snailpositions[0][i];
        int sxpos2 = snailpositions[0][i + 1];
        int sypos1 = snailpositions[1][i];
        int sypos2 = snailpositions[1][i + 1];

        // printf("X1: %i X2: %i ", sxpos1, sxpos2);
        // printf("Y1: %i Y2: %i\n", sypos1, sypos2);

        int diffx = 0;
        int diffy = 0;

        // pos1 < pos2 section
        if (sxpos1 < sxpos2)
        {
            diffx = sxpos2 - sxpos1;
        }
        if (sypos1 < sypos2)
        {
            diffy = sypos2 - sypos1;
        }

        // pos1 > pos2 section
        if (sxpos1 > sxpos2)
        {
            diffx = sxpos1 - sxpos2;
        }
        if (sypos1 > sypos2)
        {
            diffy = sypos1 - sypos2;
        }

        if (diffx == 0 && diffy == 0)
        {
            allpositions[0][atallposindex] = sxpos1;
            allpositions[1][atallposindex] = sypos1;
            atallposindex++;
        }

        if (diffx > 0 && diffy == 0)
        {
            if (sxpos1 < sxpos2)
            {
                for (size_t j = 0; j < diffx; j++)
                {
                    sxpos1++;
                    allpositions[0][atallposindex] = sxpos1;
                    allpositions[1][atallposindex] = allpositions[1][atallposindex - 1];
                    atallposindex++;
                }
            }

            if (sxpos1 > sxpos2)
            {
                for (size_t j = 0; j < diffx; j++)
                {
                    sxpos1--;
                    allpositions[0][atallposindex] = sxpos1;
                    allpositions[1][atallposindex] = allpositions[1][atallposindex - 1];
                    atallposindex++;
                }
            }
        }

        if (diffx == 0 && diffy > 0)
        {
            if (sypos1 < sypos2)
            {
                for (size_t j = 0; j < diffy; j++)
                {
                    sypos1++;
                    allpositions[1][atallposindex] = sypos1;
                    allpositions[0][atallposindex] = sxpos1;
                    atallposindex++;
                }
            }

            if (sypos1 > sypos2)
            {
                for (size_t j = 0; j < diffy; j++)
                {
                    sypos1--;
                    allpositions[1][atallposindex] = sypos1;
                    allpositions[0][atallposindex] = sxpos1;
                    atallposindex++;
                }
            }
        }
    }

    for (size_t i = 0; i < 10; i++)
    {
        printf("X: %i, Y: %i\n", allpositions[0][i], allpositions[1][i]);
    }
    printf("allPosIndex: %i\n", atallposindex);

    int validvaluesinarray = 0;
    for (size_t i = 0; i < 20; i++)
    {
        for (size_t j = 0; j < 20; j++)
        {
            if (snailarr[i][j] != 0)
            {
                validvaluesinarray++;
            }
        }
    }
    // int *output = malloc(sizeof(int) * validvaluesinarray);

    printf("\n");

    printf("---------------------------------------\n");
    free(storage);
    // char *readchar = malloc(sizeof(char));
    // scanf("%c", readchar);
    return 0;
}