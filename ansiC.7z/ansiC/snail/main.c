#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

int main(int argc, char **argv)
{
    // Create def vars for storing data
    unsigned int charCountInFile = 1; // includes nullterm char, aka storage length
    char *storage;                    // char array to store our data

    // counting chars in file
    // hello.txt <- path placeholder
    FILE *fp = fopen("hello.txt", "r");
    for (char tempchar = getc(fp); tempchar != EOF; tempchar = getc(fp))
    {
        charCountInFile = charCountInFile + 1;
    }
    fclose(fp);

    // dyn alloc mem for our arr
    storage = malloc(sizeof(char) * charCountInFile);

    // load data into our arr
    // hello.txt <- path placeholder
    fp = fopen("hello.txt", "r");
    char c;
    for (unsigned int i = 0; i < charCountInFile; i++)
    {
        c = getc(fp);
        if (c == EOF)
        {
            storage[i] = 0x00;
            break;
        }

        // LOOK AT THIS MAN, this is how to use our char arr!
        storage[i] = c;
    }
    fclose(fp);

    // print charcount
    printf("charcount in file: %i\n", charCountInFile);
    // print data
    printf("%s", storage);

    printf("\n");

    // example to convert 2 char number into 1 numeric val
    char buffer1[20];
    char buffer2[20];
    int num1 = 23;
    int num2 = 69;
    sprintf(buffer1, "%d", num1);
    sprintf(buffer2, "%d", num2);
    strcat(buffer1, buffer2);
    int outputnumber = atoi(buffer1);
    printf("%i", outputnumber);

    // TODO: Implement Turtle LOGIX

    // don't touch this below
    printf("\n");
    free(storage);
    free(fp);
    return 0;
}